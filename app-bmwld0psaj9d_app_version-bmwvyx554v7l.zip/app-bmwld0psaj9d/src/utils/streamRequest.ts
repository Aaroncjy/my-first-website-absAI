// 通用流式请求函数（App平台，使用expo/fetch支持流式body）
import { fetch } from 'expo/fetch';
import { processSSEStream } from './sseStream';
import type { ChatMessage } from '@/types/types';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

export interface StreamRequestOptions {
  messages: ChatMessage[];
  onChunk: (chunk: string) => void;
  onComplete: () => void;
  onError: (error: Error) => void;
  signal?: AbortSignal;
}

export const sendAIStreamRequest = async (options: StreamRequestOptions): Promise<void> => {
  const { messages, onChunk, onComplete, onError, signal } = options;

  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/multimodal-chat`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${supabaseAnonKey}`,
        apikey: supabaseAnonKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ messages }),
      signal,
    });

    if (!response.ok) {
      throw new Error(`请求失败: ${response.status}`);
    }

    processSSEStream(signal, response as unknown as Response, {
      onData: (data) => {
        if (data === '[DONE]') return;
        try {
          const chunk = JSON.parse(data).choices?.[0]?.delta?.content ?? '';
          if (chunk) onChunk(chunk);
        } catch {
          // 不完整chunk，跳过
        }
      },
      onCompleted: (error) => (error ? onError(error) : onComplete()),
      onAborted: () => {},
    });
  } catch (error) {
    if (!signal?.aborted) {
      onError(error as Error);
    }
  }
};
