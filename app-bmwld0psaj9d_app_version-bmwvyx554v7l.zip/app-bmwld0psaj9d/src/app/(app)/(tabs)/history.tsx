import { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  Text,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSession } from '@/ctx';
import { createConversation, deleteConversation, getConversations } from '@/db/api';
import { NEU_SHADOW } from '@/lib/neumorph';
import type { Conversation } from '@/types/types';

export default function HistoryTab() {
  const router = useRouter();
  const { session } = useSession();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      if (!session?.user?.id) return;
      loadConversations();
    }, [session?.user?.id])
  );

  const loadConversations = async () => {
    if (!session?.user?.id) return;
    setLoading(true);
    const data = await getConversations(session.user.id);
    setConversations(data);
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    setDeleting(id);
    await deleteConversation(id);
    setConversations((prev) => prev.filter((c) => c.id !== id));
    setDeleting(null);
    setConfirmDeleteId(null);
  };

  const handleNewChat = async () => {
    if (!session?.user?.id || creating) return;
    setCreating(true);
    const conv = await createConversation(session.user.id, '新对话');
    setCreating(false);
    if (conv) router.push(`/(app)/chat/${conv.id}`);
  };

  const formatDate = (ts: string) => {
    const d = new Date(ts);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffH = diffMs / 3600000;
    const diffD = diffMs / 86400000;

    if (diffH < 1) return '刚刚';
    if (diffH < 24) return `${Math.floor(diffH)}小时前`;
    if (diffD < 7) return `${Math.floor(diffD)}天前`;
    return d.toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric' });
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#dde1e7' }}>
      {/* 顶部 */}
      <View
        style={{
          paddingTop: 56,
          paddingHorizontal: 24,
          paddingBottom: 20,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <View>
          <Text
            style={{
              fontFamily: 'Glow Sans SC',
              fontSize: 22,
              fontWeight: '700',
              color: '#3a3f5c',
            }}
          >
            对话历史
          </Text>
          <Text
            style={{
              fontFamily: 'Glow Sans SC',
              fontSize: 12,
              color: '#8a9ab5',
              marginTop: 2,
            }}
          >
            共 {conversations.length} 条记录
          </Text>
        </View>

        <Pressable
          onPress={handleNewChat}
          disabled={creating}
          style={({ pressed }) => ({
            width: 42,
            height: 42,
            borderRadius: 13,
            backgroundColor: '#6376c8',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.primary,
          })}
        >
          {creating ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Ionicons name="add" size={22} color="#fff" />
          )}
        </Pressable>
      </View>

      {/* 列表 */}
      {loading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color="#6376c8" />
        </View>
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
          ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
          ListEmptyComponent={
            <View
              style={{
                alignItems: 'center',
                paddingTop: 80,
                paddingHorizontal: 40,
              }}
            >
              <View
                style={{
                  width: 64,
                  height: 64,
                  borderRadius: 18,
                  backgroundColor: '#dde1e7',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: NEU_SHADOW.raised,
                  marginBottom: 16,
                }}
              >
                <Text style={{ fontSize: 28 }}>🕐</Text>
              </View>
              <Text
                style={{
                  fontFamily: 'Glow Sans SC',
                  fontSize: 15,
                  fontWeight: '600',
                  color: '#4a5580',
                  marginBottom: 8,
                  textAlign: 'center',
                }}
              >
                暂无对话记录
              </Text>
              <Text
                style={{
                  fontFamily: 'Glow Sans SC',
                  fontSize: 13,
                  color: '#8a9ab5',
                  textAlign: 'center',
                  lineHeight: 20,
                }}
              >
                点击右上角 + 开始新对话
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <View>
              <Pressable
                onPress={() => {
                  setConfirmDeleteId(null);
                  router.push(`/(app)/chat/${item.id}`);
                }}
                style={({ pressed }) => ({
                  backgroundColor: '#dde1e7',
                  borderRadius: 18,
                  padding: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 14,
                  boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                  transform: [{ scale: pressed ? 0.98 : 1 }],
                })}
              >
                <View
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 13,
                    backgroundColor: '#dde1e7',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: NEU_SHADOW.raisedSm,
                    flexShrink: 0,
                  }}
                >
                  <Text style={{ fontSize: 20 }}>💬</Text>
                </View>

                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text
                    style={{
                      fontFamily: 'Glow Sans SC',
                      fontSize: 14,
                      fontWeight: '700',
                      color: '#3a3f5c',
                    }}
                    numberOfLines={1}
                  >
                    {item.title}
                  </Text>
                  <Text
                    style={{
                      fontFamily: 'Glow Sans SC',
                      fontSize: 11,
                      color: '#a0aec0',
                      marginTop: 3,
                    }}
                  >
                    {formatDate(item.updated_at)}
                  </Text>
                </View>

                {/* 删除/确认删除按钮 */}
                {confirmDeleteId === item.id ? (
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <Pressable
                      onPress={() => handleDelete(item.id)}
                      style={({ pressed }) => ({
                        paddingHorizontal: 12,
                        paddingVertical: 7,
                        borderRadius: 10,
                        backgroundColor: '#e05555',
                        boxShadow: pressed ? NEU_SHADOW.pressed : '2px 2px 6px rgba(224,85,85,0.4)',
                      })}
                    >
                      {deleting === item.id ? (
                        <ActivityIndicator size="small" color="#fff" />
                      ) : (
                        <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 12, color: '#fff', fontWeight: '600' }}>
                          确认
                        </Text>
                      )}
                    </Pressable>
                    <Pressable
                      onPress={() => setConfirmDeleteId(null)}
                      style={({ pressed }) => ({
                        paddingHorizontal: 12,
                        paddingVertical: 7,
                        borderRadius: 10,
                        backgroundColor: '#dde1e7',
                        boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                      })}
                    >
                      <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 12, color: '#8a9ab5' }}>
                        取消
                      </Text>
                    </Pressable>
                  </View>
                ) : (
                  <Pressable
                    onPress={(e) => {
                      e.stopPropagation?.();
                      setConfirmDeleteId(item.id);
                    }}
                    style={({ pressed }) => ({
                      width: 34,
                      height: 34,
                      borderRadius: 10,
                      backgroundColor: '#dde1e7',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                    })}
                  >
                    <Ionicons name="trash" size={16} color="#a0aec0" />
                  </Pressable>
                )}
              </Pressable>
            </View>
          )}
        />
      )}
    </View>
  );
}
