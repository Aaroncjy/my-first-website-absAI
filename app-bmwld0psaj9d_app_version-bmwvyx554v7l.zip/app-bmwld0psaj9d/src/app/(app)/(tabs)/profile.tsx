import { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/client/supabase';
import { useSession } from '@/ctx';
import { getProfile, updateProfile } from '@/db/api';
import { NEU_SHADOW } from '@/lib/neumorph';
import type { Profile } from '@/types/types';

export default function ProfileTab() {
  const router = useRouter();
  const { session } = useSession();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [username, setUsername] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  useFocusEffect(
    useCallback(() => {
      if (!session?.user?.id) return;
      loadProfile();
    }, [session?.user?.id])
  );

  const loadProfile = async () => {
    if (!session?.user?.id) return;
    setLoading(true);
    const p = await getProfile(session.user.id);
    setProfile(p);
    setUsername(p?.username ?? extractUsername(session.user.email ?? ''));
    setLoading(false);
  };

  const extractUsername = (email: string) =>
    email.replace('@miaoda.com', '');

  const handleSave = async () => {
    if (!session?.user?.id || !username.trim()) return;
    setSaving(true);
    await updateProfile(session.user.id, { username: username.trim() });
    setSaving(false);
    setSaveSuccess(true);
    setEditing(false);
    setTimeout(() => setSaveSuccess(false), 2000);
    await loadProfile();
  };

  const handleSignOut = async () => {
    setSigningOut(true);
    await supabase.auth.signOut();
    router.replace('/');
  };

  const displayName = profile?.username || extractUsername(session?.user?.email ?? '');
  const userEmail = session?.user?.email ?? '';
  const isAdmin = profile?.role === 'admin';

  return (
    <View style={{ flex: 1, backgroundColor: '#dde1e7' }}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
      >
        {/* 顶部标题 */}
        <View style={{ paddingTop: 56, paddingHorizontal: 24, paddingBottom: 24 }}>
          <Text
            style={{
              fontFamily: 'Glow Sans SC',
              fontSize: 22,
              fontWeight: '700',
              color: '#3a3f5c',
            }}
          >
            我的
          </Text>
        </View>

        {loading ? (
          <View style={{ alignItems: 'center', paddingTop: 40 }}>
            <ActivityIndicator color="#6376c8" />
          </View>
        ) : (
          <>
            {/* 用户信息卡片 */}
            <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
              <View
                style={{
                  backgroundColor: '#dde1e7',
                  borderRadius: 22,
                  padding: 24,
                  alignItems: 'center',
                  boxShadow: NEU_SHADOW.raised,
                }}
              >
                {/* 头像 */}
                <View
                  style={{
                    width: 80,
                    height: 80,
                    borderRadius: 24,
                    backgroundColor: '#6376c8',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: NEU_SHADOW.primary,
                    marginBottom: 16,
                  }}
                >
                  <Text style={{ fontSize: 32, color: '#fff', fontWeight: '700' }}>
                    {displayName.charAt(0).toUpperCase()}
                  </Text>
                </View>

                {/* 用户名编辑 */}
                {editing ? (
                  <View style={{ width: '100%', gap: 12 }}>
                    <TextInput
                      style={{
                        backgroundColor: '#dde1e7',
                        borderRadius: 14,
                        paddingHorizontal: 16,
                        paddingVertical: 12,
                        fontSize: 15,
                        color: '#3a3f5c',
                        fontFamily: 'Glow Sans SC',
                        textAlign: 'center',
                        boxShadow: NEU_SHADOW.inset,
                      }}
                      value={username}
                      onChangeText={setUsername}
                      placeholder="输入昵称"
                      placeholderTextColor="#a0aec0"
                      autoFocus
                    />
                    <View style={{ flexDirection: 'row', gap: 10 }}>
                      <Pressable
                        onPress={handleSave}
                        disabled={saving}
                        style={({ pressed }) => ({
                          flex: 1,
                          paddingVertical: 12,
                          borderRadius: 13,
                          backgroundColor: '#6376c8',
                          alignItems: 'center',
                          boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.primary,
                        })}
                      >
                        {saving ? (
                          <ActivityIndicator color="#fff" size="small" />
                        ) : (
                          <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 14, color: '#fff', fontWeight: '700' }}>
                            保存
                          </Text>
                        )}
                      </Pressable>
                      <Pressable
                        onPress={() => { setEditing(false); setUsername(displayName); }}
                        style={({ pressed }) => ({
                          flex: 1,
                          paddingVertical: 12,
                          borderRadius: 13,
                          backgroundColor: '#dde1e7',
                          alignItems: 'center',
                          boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                        })}
                      >
                        <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 14, color: '#8a9ab5' }}>
                          取消
                        </Text>
                      </Pressable>
                    </View>
                  </View>
                ) : (
                  <>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <Text
                        style={{
                          fontFamily: 'Glow Sans SC',
                          fontSize: 20,
                          fontWeight: '700',
                          color: '#3a3f5c',
                        }}
                      >
                        {displayName}
                      </Text>
                      <Pressable
                        onPress={() => setEditing(true)}
                        style={({ pressed }) => ({
                          width: 28,
                          height: 28,
                          borderRadius: 8,
                          backgroundColor: '#dde1e7',
                          alignItems: 'center',
                          justifyContent: 'center',
                          boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                        })}
                      >
                        <Ionicons name="create" size={14} color="#8a9ab5" />
                      </Pressable>
                    </View>

                    {isAdmin && (
                      <View
                        style={{
                          backgroundColor: '#6376c8',
                          paddingHorizontal: 10,
                          paddingVertical: 3,
                          borderRadius: 8,
                          marginBottom: 8,
                        }}
                      >
                        <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 11, color: '#fff', fontWeight: '600' }}>
                          管理员
                        </Text>
                      </View>
                    )}

                    <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 12, color: '#a0aec0' }}>
                      {userEmail.replace('@miaoda.com', '')}
                    </Text>

                    {saveSuccess && (
                      <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 12, color: '#6376c8', marginTop: 8 }}>
                        ✓ 保存成功
                      </Text>
                    )}
                  </>
                )}
              </View>
            </View>

            {/* 设置选项 */}
            <View style={{ paddingHorizontal: 20, gap: 12 }}>
              {/* 账号安全 */}
              <View
                style={{
                  backgroundColor: '#dde1e7',
                  borderRadius: 18,
                  overflow: 'hidden',
                  boxShadow: NEU_SHADOW.raisedSm,
                }}
              >
                <Text
                  style={{
                    fontFamily: 'Glow Sans SC',
                    fontSize: 12,
                    color: '#8a9ab5',
                    fontWeight: '600',
                    padding: 16,
                    paddingBottom: 8,
                  }}
                >
                  账号信息
                </Text>
                {[
                  { icon: 'person-outline', label: '用户名', value: displayName },
                  { icon: 'mail-outline', label: '账号ID', value: userEmail.replace('@miaoda.com', '') },
                  { icon: 'shield-outline', label: '账号角色', value: isAdmin ? '管理员' : '普通用户' },
                ].map((item, idx, arr) => (
                  <View
                    key={item.label}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      paddingHorizontal: 16,
                      paddingVertical: 14,
                      borderTopWidth: idx === 0 ? 0 : 1,
                      borderTopColor: 'rgba(163,177,198,0.3)',
                      gap: 14,
                    }}
                  >
                    <View
                      style={{
                        width: 36,
                        height: 36,
                        borderRadius: 10,
                        backgroundColor: '#dde1e7',
                        alignItems: 'center',
                        justifyContent: 'center',
                        boxShadow: NEU_SHADOW.raisedSm,
                      }}
                    >
                      <Ionicons name={item.icon as any} size={17} color="#6376c8" />
                    </View>
                    <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 14, color: '#4a5580', flex: 1 }}>
                      {item.label}
                    </Text>
                    <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 13, color: '#a0aec0' }}>
                      {item.value}
                    </Text>
                  </View>
                ))}
              </View>

              {/* 关于 */}
              <View
                style={{
                  backgroundColor: '#dde1e7',
                  borderRadius: 18,
                  overflow: 'hidden',
                  boxShadow: NEU_SHADOW.raisedSm,
                }}
              >
                <Text
                  style={{
                    fontFamily: 'Glow Sans SC',
                    fontSize: 12,
                    color: '#8a9ab5',
                    fontWeight: '600',
                    padding: 16,
                    paddingBottom: 8,
                  }}
                >
                  关于
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    paddingHorizontal: 16,
                    paddingVertical: 14,
                    gap: 14,
                  }}
                >
                  <View
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 10,
                      backgroundColor: '#6376c8',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: NEU_SHADOW.primary,
                    }}
                  >
                    <Text style={{ fontSize: 16 }}>✦</Text>
                  </View>
                  <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 14, color: '#4a5580', flex: 1 }}>
                    abstractAI
                  </Text>
                  <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 13, color: '#a0aec0' }}>
                    v1.0.0
                  </Text>
                </View>
              </View>

              {/* 退出登录 */}
              {!showLogoutConfirm ? (
                <Pressable
                  onPress={() => setShowLogoutConfirm(true)}
                  style={({ pressed }) => ({
                    backgroundColor: '#dde1e7',
                    borderRadius: 18,
                    padding: 18,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 10,
                    boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                  })}
                >
                  <Ionicons name="log-out-outline" size={18} color="#e05555" />
                  <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 15, color: '#e05555', fontWeight: '600' }}>
                    退出登录
                  </Text>
                </Pressable>
              ) : (
                <View
                  style={{
                    backgroundColor: '#dde1e7',
                    borderRadius: 18,
                    padding: 20,
                    boxShadow: NEU_SHADOW.raisedSm,
                    gap: 14,
                  }}
                >
                  <Text
                    style={{
                      fontFamily: 'Glow Sans SC',
                      fontSize: 14,
                      color: '#4a5580',
                      textAlign: 'center',
                      fontWeight: '600',
                    }}
                  >
                    确认退出登录？
                  </Text>
                  <View style={{ flexDirection: 'row', gap: 12 }}>
                    <Pressable
                      onPress={handleSignOut}
                      disabled={signingOut}
                      style={({ pressed }) => ({
                        flex: 1,
                        paddingVertical: 13,
                        borderRadius: 13,
                        backgroundColor: '#e05555',
                        alignItems: 'center',
                        boxShadow: pressed ? NEU_SHADOW.pressed : '3px 3px 8px rgba(224,85,85,0.4)',
                      })}
                    >
                      {signingOut ? (
                        <ActivityIndicator color="#fff" size="small" />
                      ) : (
                        <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 14, color: '#fff', fontWeight: '700' }}>
                          确认退出
                        </Text>
                      )}
                    </Pressable>
                    <Pressable
                      onPress={() => setShowLogoutConfirm(false)}
                      style={({ pressed }) => ({
                        flex: 1,
                        paddingVertical: 13,
                        borderRadius: 13,
                        backgroundColor: '#dde1e7',
                        alignItems: 'center',
                        boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                      })}
                    >
                      <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 14, color: '#8a9ab5' }}>
                        取消
                      </Text>
                    </Pressable>
                  </View>
                </View>
              )}
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}
