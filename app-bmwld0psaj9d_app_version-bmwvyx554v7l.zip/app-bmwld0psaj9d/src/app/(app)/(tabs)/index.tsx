import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSession } from '@/ctx';
import { createConversation, getConversations } from '@/db/api';
import { NEU_SHADOW } from '@/lib/neumorph';
import type { Conversation } from '@/types/types';

export default function HomeTab() {
  const router = useRouter();
  const { session } = useSession();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  // 每次聚焦都刷新
  useFocusEffect(
    useCallback(() => {
      if (!session?.user?.id) return;
      loadConversations();
    }, [session?.user?.id])
  );

  const loadConversations = async () => {
    if (!session?.user?.id) return;
    setLoading(true);
    const data = await getConversations(session.user.id);
    setConversations(data.slice(0, 5)); // 首页显示最近5条
    setLoading(false);
  };

  const handleNewChat = async () => {
    if (!session?.user?.id || creating) return;
    setCreating(true);
    const conv = await createConversation(session.user.id, '新对话');
    setCreating(false);
    if (conv) {
      router.push(`/(app)/chat/${conv.id}`);
    }
  };

  const formatTime = (ts: string) => {
    const d = new Date(ts);
    const now = new Date();
    const diffH = (now.getTime() - d.getTime()) / 3600000;
    if (diffH < 24) return d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    return d.toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric' });
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#dde1e7' }}>
      {/* 顶部标题区 */}
      <View
        style={{
          paddingTop: 56,
          paddingHorizontal: 24,
          paddingBottom: 24,
          backgroundColor: '#dde1e7',
        }}
      >
        <Text
          style={{
            fontFamily: 'Glow Sans SC',
            fontSize: 26,
            fontWeight: '700',
            color: '#3a3f5c',
          }}
        >
          abstractAI
        </Text>
        <Text
          style={{
            fontFamily: 'Glow Sans SC',
            fontSize: 13,
            color: '#8a9ab5',
            marginTop: 4,
          }}
        >
          你好，有什么我可以帮你的？
        </Text>
      </View>

      {/* 新建对话大按钮 */}
      <View style={{ paddingHorizontal: 24, marginBottom: 28 }}>
        <Pressable
          onPress={handleNewChat}
          disabled={creating}
          style={({ pressed }) => ({
            borderRadius: 22,
            backgroundColor: '#6376c8',
            paddingVertical: 18,
            paddingHorizontal: 24,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 12,
            boxShadow: pressed
              ? '2px 2px 6px rgba(99,118,200,0.4)'
              : '6px 6px 14px rgba(99,118,200,0.45), -3px -3px 8px rgba(255,255,255,0.55)',
            transform: [{ scale: pressed ? 0.97 : 1 }],
          })}
        >
          {creating ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Ionicons name="add-circle" size={22} color="#fff" />
              <Text
                style={{
                  fontFamily: 'Glow Sans SC',
                  fontSize: 16,
                  fontWeight: '700',
                  color: '#fff',
                }}
              >
                开始新对话
              </Text>
            </>
          )}
        </Pressable>
      </View>

      {/* 功能卡片区 */}
      <View style={{ paddingHorizontal: 24, marginBottom: 24 }}>
        <Text
          style={{
            fontFamily: 'Glow Sans SC',
            fontSize: 14,
            color: '#8a9ab5',
            marginBottom: 16,
            fontWeight: '600',
          }}
        >
          AI 能力
        </Text>
        <View style={{ flexDirection: 'row', gap: 14 }}>
          {[
            { icon: '🔬', label: '深度研究', desc: '全面分析报告' },
            { icon: '📊', label: '数据分析', desc: '洞察数据规律' },
            { icon: '🎨', label: '图片生成', desc: '创意图像创作' },
            { icon: '🎬', label: '视频生成', desc: 'AI 视频创作' },
          ].map((item) => (
            <Pressable
              key={item.label}
              onPress={handleNewChat}
              style={({ pressed }) => ({
                flex: 1,
                backgroundColor: '#dde1e7',
                borderRadius: 18,
                padding: 14,
                alignItems: 'center',
                gap: 6,
                boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                transform: [{ scale: pressed ? 0.96 : 1 }],
              })}
            >
              <Text style={{ fontSize: 24 }}>{item.icon}</Text>
              <Text
                style={{
                  fontFamily: 'Glow Sans SC',
                  fontSize: 11,
                  fontWeight: '700',
                  color: '#4a5580',
                }}
              >
                {item.label}
              </Text>
              <Text
                style={{
                  fontFamily: 'Glow Sans SC',
                  fontSize: 9,
                  color: '#8a9ab5',
                  textAlign: 'center',
                }}
              >
                {item.desc}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* 最近对话 */}
      <View style={{ flex: 1, paddingHorizontal: 24 }}>
        <Text
          style={{
            fontFamily: 'Glow Sans SC',
            fontSize: 14,
            color: '#8a9ab5',
            marginBottom: 14,
            fontWeight: '600',
          }}
        >
          最近对话
        </Text>

        {loading ? (
          <View style={{ alignItems: 'center', paddingTop: 20 }}>
            <ActivityIndicator color="#6376c8" />
          </View>
        ) : conversations.length === 0 ? (
          <View
            style={{
              backgroundColor: '#dde1e7',
              borderRadius: 18,
              padding: 24,
              alignItems: 'center',
              boxShadow: NEU_SHADOW.raisedSm,
            }}
          >
            <Text style={{ fontSize: 32, marginBottom: 10 }}>💬</Text>
            <Text
              style={{
                fontFamily: 'Glow Sans SC',
                fontSize: 14,
                color: '#8a9ab5',
                textAlign: 'center',
              }}
            >
              还没有对话记录{'\n'}点击上方按钮开始吧
            </Text>
          </View>
        ) : (
          <FlatList
            data={conversations}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
            renderItem={({ item }) => (
              <Pressable
                onPress={() => router.push(`/(app)/chat/${item.id}`)}
                style={({ pressed }) => ({
                  backgroundColor: '#dde1e7',
                  borderRadius: 16,
                  padding: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 14,
                  boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                  transform: [{ scale: pressed ? 0.98 : 1 }],
                })}
              >
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 12,
                    backgroundColor: '#dde1e7',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: NEU_SHADOW.raisedSm,
                  }}
                >
                  <Text style={{ fontSize: 18 }}>💬</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontFamily: 'Glow Sans SC',
                      fontSize: 14,
                      fontWeight: '600',
                      color: '#3a3f5c',
                    }}
                    numberOfLines={1}
                  >
                    {item.title}
                  </Text>
                  <Text
                    style={{
                      fontFamily: 'Glow Sans SC',
                      fontSize: 11,
                      color: '#a0aec0',
                      marginTop: 2,
                    }}
                  >
                    {formatTime(item.updated_at)}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color="#a0aec0" />
              </Pressable>
            )}
          />
        )}
      </View>
    </View>
  );
}
