import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

export default function TabsLayout() {
  return (
    <>
      <StatusBar style="dark" backgroundColor="#dde1e7" />
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: '#6376c8',
          tabBarInactiveTintColor: '#a0aec0',
          tabBarStyle: {
            backgroundColor: '#dde1e7',
            borderTopWidth: 0,
            height: 72,
            paddingBottom: 12,
            paddingTop: 8,
            boxShadow: '-2px -4px 12px rgba(255,255,255,0.7), 2px -2px 10px rgba(163,177,198,0.4)',
          },
          tabBarLabelStyle: {
            fontFamily: 'Glow Sans SC',
            fontSize: 11,
            fontWeight: '600',
          },
        }}
      >
        <Tabs.Screen
          name="index"
          options={{
            title: '对话',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="chatbubble-ellipses" size={size} color={color} />
            ),
          }}
        />
        <Tabs.Screen
          name="history"
          options={{
            title: '历史',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="time" size={size} color={color} />
            ),
          }}
        />
        <Tabs.Screen
          name="profile"
          options={{
            title: '我的',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="person" size={size} color={color} />
            ),
          }}
        />
      </Tabs>
    </>
  );
}
