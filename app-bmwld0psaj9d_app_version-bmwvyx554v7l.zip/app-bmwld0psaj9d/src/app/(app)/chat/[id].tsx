import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Pressable,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import Markdown from 'react-native-marked';
import { Ionicons } from '@expo/vector-icons';
import { useSession } from '@/ctx';
import { getMessages, insertMessage, updateConversationTitle } from '@/db/api';
import { sendAIStreamRequest } from '@/utils/streamRequest';
import { NEU_SHADOW } from '@/lib/neumorph';
import type { ChatBubble, ChatMessage } from '@/types/types';

// AI系统提示
const SYSTEM_PROMPT = `你是 abstractAI，一个由 abstractAI 团队自主研发的强大 AI 助手。你具备深度研究、数据分析、图像理解、知识问答等综合能力，能够准确、智慧地回答用户的各类问题。
你的特点：
- 知识渊博，能够正确回答各领域的专业问题
- 逻辑严谨，分析问题条理清晰
- 语言自然，善于用通俗易懂的方式解释复杂概念
- 积极主动，会主动提供有价值的补充信息
请始终以中文回复，保持专业、友好的语气。`;

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { session } = useSession();
  const [messages, setMessages] = useState<ChatBubble[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [streaming, setStreaming] = useState(false);
  const flatListRef = useRef<FlatList>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const streamingContentRef = useRef('');
  const isFirstMessage = useRef(true);

  useEffect(() => {
    if (id) loadMessages();
    return () => { abortControllerRef.current?.abort(); };
  }, [id]);

  const loadMessages = async () => {
    const msgs = await getMessages(id);
    if (msgs.length > 0) {
      isFirstMessage.current = false;
      setMessages(
        msgs.map((m) => ({
          id: m.id,
          role: m.role as 'user' | 'assistant',
          content: m.content,
        }))
      );
    }
    setLoading(false);
  };

  const scrollToBottom = useCallback(() => {
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
  }, []);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || streaming) return;

    setInput('');

    // 插入用户消息气泡
    const userBubbleId = `user-${Date.now()}`;
    const aiBubbleId = `ai-${Date.now()}`;

    setMessages((prev) => [
      ...prev,
      { id: userBubbleId, role: 'user', content: text },
      { id: aiBubbleId, role: 'assistant', content: '', isStreaming: true },
    ]);
    scrollToBottom();

    // 持久化用户消息
    await insertMessage(id, 'user', text);

    // 如果是第一条消息，用内容作为对话标题
    if (isFirstMessage.current) {
      isFirstMessage.current = false;
      const title = text.length > 20 ? text.slice(0, 20) + '…' : text;
      await updateConversationTitle(id, title);
    }

    // 构建AI消息历史（取最近10条避免超token）
    const allMessages = [
      ...messages.filter((m) => !m.isStreaming),
      { id: userBubbleId, role: 'user' as const, content: text },
    ];
    const recentMessages = allMessages.slice(-10);
    const chatMessages: ChatMessage[] = [
      {
        role: 'system',
        content: [{ type: 'text', text: SYSTEM_PROMPT }],
      },
      ...recentMessages.map((m) => ({
        role: m.role as 'user' | 'assistant',
        content: [{ type: 'text' as const, text: m.content }],
      })),
    ];

    streamingContentRef.current = '';
    abortControllerRef.current = new AbortController();
    setStreaming(true);

    await sendAIStreamRequest({
      messages: chatMessages,
      signal: abortControllerRef.current.signal,
      onChunk: (chunk) => {
        streamingContentRef.current += chunk;
        setMessages((prev) =>
          prev.map((m) =>
            m.id === aiBubbleId
              ? { ...m, content: streamingContentRef.current }
              : m
          )
        );
        scrollToBottom();
      },
      onComplete: async () => {
        const finalContent = streamingContentRef.current;
        setMessages((prev) =>
          prev.map((m) =>
            m.id === aiBubbleId
              ? { ...m, content: finalContent, isStreaming: false }
              : m
          )
        );
        setStreaming(false);
        // 持久化AI消息
        await insertMessage(id, 'assistant', finalContent);
      },
      onError: (error) => {
        console.error('AI请求错误:', error);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === aiBubbleId
              ? { ...m, content: '抱歉，AI 暂时无法回答，请稍后重试。', isStreaming: false }
              : m
          )
        );
        setStreaming(false);
      },
    });
  };

  const handleAbort = () => {
    abortControllerRef.current?.abort();
    setStreaming(false);
    setMessages((prev) =>
      prev.map((m) => (m.isStreaming ? { ...m, isStreaming: false } : m))
    );
  };

  const renderMessage = ({ item }: { item: ChatBubble }) => {
    const isUser = item.role === 'user';

    return (
      <View
        style={{
          flexDirection: 'row',
          justifyContent: isUser ? 'flex-end' : 'flex-start',
          paddingHorizontal: 16,
          marginVertical: 6,
        }}
      >
        {!isUser && (
          <View
            style={{
              width: 32,
              height: 32,
              borderRadius: 10,
              backgroundColor: '#6376c8',
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: 8,
              marginTop: 2,
              flexShrink: 0,
            }}
          >
            <Text style={{ fontSize: 14 }}>✦</Text>
          </View>
        )}

        <View
          style={{
            maxWidth: '78%',
            backgroundColor: isUser ? '#6376c8' : '#dde1e7',
            borderRadius: isUser ? 18 : 18,
            borderBottomRightRadius: isUser ? 4 : 18,
            borderBottomLeftRadius: isUser ? 18 : 4,
            paddingHorizontal: 16,
            paddingVertical: 11,
            boxShadow: isUser
              ? '3px 3px 8px rgba(99,118,200,0.35), -2px -2px 5px rgba(255,255,255,0.4)'
              : NEU_SHADOW.raisedSm,
          }}
        >
          {item.isStreaming && item.content === '' ? (
            <View style={{ flexDirection: 'row', gap: 4, paddingVertical: 4 }}>
              <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: '#8a9ab5' }} />
              <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: '#8a9ab5' }} />
              <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: '#8a9ab5' }} />
            </View>
          ) : isUser ? (
            <Text
              style={{
                fontFamily: 'Glow Sans SC',
                fontSize: 14,
                color: '#fff',
                lineHeight: 22,
              }}
            >
              {item.content}
            </Text>
          ) : (
            <Markdown
              value={item.content || ' '}
              flatListProps={{ scrollEnabled: false }}
              styles={{
                text: {
                  fontFamily: 'Glow Sans SC',
                  fontSize: 14,
                  color: '#3a3f5c',
                  lineHeight: 22,
                },
              }}
            />
          )}
        </View>
      </View>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#dde1e7' }}>
      <StatusBar style="dark" backgroundColor="#dde1e7" />

      {/* 顶部导航栏 */}
      <View
        style={{
          paddingTop: 52,
          paddingBottom: 14,
          paddingHorizontal: 16,
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: '#dde1e7',
          boxShadow: '0px 4px 12px rgba(163,177,198,0.4)',
          gap: 12,
        }}
      >
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => ({
            width: 38,
            height: 38,
            borderRadius: 12,
            backgroundColor: '#dde1e7',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
          })}
        >
          <Ionicons name="arrow-back" size={20} color="#4a5580" />
        </Pressable>

        <View
          style={{
            width: 32,
            height: 32,
            borderRadius: 10,
            backgroundColor: '#6376c8',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Text style={{ fontSize: 14 }}>✦</Text>
        </View>

        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: 'Glow Sans SC',
              fontSize: 16,
              fontWeight: '700',
              color: '#3a3f5c',
            }}
          >
            abstractAI
          </Text>
          <Text
            style={{
              fontFamily: 'Glow Sans SC',
              fontSize: 11,
              color: streaming ? '#6376c8' : '#8a9ab5',
            }}
          >
            {streaming ? '正在思考中…' : '在线'}
          </Text>
        </View>

        {streaming && (
          <Pressable
            onPress={handleAbort}
            style={({ pressed }) => ({
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 12,
              backgroundColor: '#dde1e7',
              boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
            })}
          >
            <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 12, color: '#e05555', fontWeight: '600' }}>
              停止
            </Text>
          </Pressable>
        )}
      </View>

      {/* 消息列表 */}
      <KeyboardAvoidingView behavior="padding" style={{ flex: 1 }}>
        {loading ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <ActivityIndicator color="#6376c8" />
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={(item) => item.id}
            renderItem={renderMessage}
            contentContainerStyle={{ paddingTop: 16, paddingBottom: 16 }}
            onContentSizeChange={() => scrollToBottom()}
            ListEmptyComponent={
              <View style={{ alignItems: 'center', justifyContent: 'center', paddingTop: 80 }}>
                <View
                  style={{
                    width: 72,
                    height: 72,
                    borderRadius: 20,
                    backgroundColor: '#dde1e7',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: NEU_SHADOW.raised,
                    marginBottom: 16,
                  }}
                >
                  <Text style={{ fontSize: 32 }}>✦</Text>
                </View>
                <Text
                  style={{
                    fontFamily: 'Glow Sans SC',
                    fontSize: 16,
                    fontWeight: '700',
                    color: '#4a5580',
                    marginBottom: 8,
                  }}
                >
                  你好，我是 abstractAI
                </Text>
                <Text
                  style={{
                    fontFamily: 'Glow Sans SC',
                    fontSize: 13,
                    color: '#8a9ab5',
                    textAlign: 'center',
                    paddingHorizontal: 40,
                    lineHeight: 20,
                  }}
                >
                  我具备深度研究、数据分析、图文理解等能力{'\n'}有什么我可以帮你的？
                </Text>
              </View>
            }
          />
        )}

        {/* 输入区域 */}
        <View
          style={{
            paddingHorizontal: 16,
            paddingVertical: 12,
            paddingBottom: 24,
            backgroundColor: '#dde1e7',
            flexDirection: 'row',
            alignItems: 'flex-end',
            gap: 12,
            boxShadow: '0px -4px 12px rgba(163,177,198,0.35)',
          }}
        >
          <View
            style={{
              flex: 1,
              backgroundColor: '#dde1e7',
              borderRadius: 18,
              paddingHorizontal: 16,
              paddingVertical: 10,
              minHeight: 46,
              maxHeight: 120,
              justifyContent: 'center',
              boxShadow: NEU_SHADOW.inset,
            }}
          >
            <TextInput
              style={{
                fontFamily: 'Glow Sans SC',
                fontSize: 14,
                color: '#3a3f5c',
                maxHeight: 100,
              }}
              placeholder="输入消息…"
              placeholderTextColor="#a0aec0"
              value={input}
              onChangeText={setInput}
              multiline
              returnKeyType="send"
              blurOnSubmit={false}
              onSubmitEditing={handleSend}
            />
          </View>

          <Pressable
            onPress={handleSend}
            disabled={!input.trim() || streaming}
            style={({ pressed }) => ({
              width: 46,
              height: 46,
              borderRadius: 14,
              backgroundColor: input.trim() && !streaming ? '#6376c8' : '#dde1e7',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: input.trim() && !streaming
                ? (pressed ? NEU_SHADOW.pressed : NEU_SHADOW.primary)
                : NEU_SHADOW.raisedSm,
              transform: [{ scale: pressed ? 0.95 : 1 }],
            })}
          >
            <Ionicons
              name="send"
              size={18}
              color={input.trim() && !streaming ? '#fff' : '#a0aec0'}
            />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
