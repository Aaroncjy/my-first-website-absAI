import { useState } from 'react';
import {
  KeyboardAvoidingView,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { supabase } from '@/client/supabase';
import { NEU_SHADOW } from '@/lib/neumorph';

type AuthMode = 'login' | 'register';

export default function SignIn() {
  const router = useRouter();
  const [mode, setMode] = useState<AuthMode>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const email = username.trim() ? `${username.trim()}@miaoda.com` : '';

  const validate = (): string => {
    if (!username.trim()) return '请输入用户名';
    if (!/^[a-zA-Z0-9_]+$/.test(username.trim())) return '用户名只能包含字母、数字和下划线';
    if (!password) return '请输入密码';
    if (password.length < 6) return '密码至少6位';
    if (mode === 'register') {
      if (password !== confirmPassword) return '两次密码不一致';
      if (!agreed) return '请同意用户协议和隐私政策';
    }
    return '';
  };

  const handleSubmit = async () => {
    const validationError = validate();
    if (validationError) { setError(validationError); return; }

    setLoading(true);
    setError('');

    if (mode === 'login') {
      const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
      if (authError) {
        setError('用户名或密码错误');
      } else {
        router.replace('/');
      }
    } else {
      const { error: authError } = await supabase.auth.signUp({ email, password });
      if (authError) {
        setError(authError.message.includes('already') ? '该用户名已被注册' : authError.message);
      } else {
        router.replace('/');
      }
    }

    setLoading(false);
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#dde1e7' }}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView behavior="padding" style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingHorizontal: 28, paddingVertical: 48 }}
          keyboardShouldPersistTaps="handled"
        >
          {/* Logo区域 */}
          <View style={{ alignItems: 'center', marginBottom: 48 }}>
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 24,
                backgroundColor: '#dde1e7',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: NEU_SHADOW.raised,
                marginBottom: 20,
              }}
            >
              <Text style={{ fontSize: 36 }}>✦</Text>
            </View>
            <Text
              style={{
                fontFamily: 'Glow Sans SC',
                fontSize: 28,
                fontWeight: '700',
                color: '#3a3f5c',
                letterSpacing: 1,
              }}
            >
              abstractAI
            </Text>
            <Text
              style={{
                fontFamily: 'Glow Sans SC',
                fontSize: 13,
                color: '#8a9ab5',
                marginTop: 6,
              }}
            >
              智能对话，无限可能
            </Text>
          </View>

          {/* 登录/注册切换 Tab */}
          <View
            style={{
              flexDirection: 'row',
              backgroundColor: '#dde1e7',
              borderRadius: 16,
              padding: 5,
              marginBottom: 28,
              boxShadow: NEU_SHADOW.inset,
            }}
          >
            {(['login', 'register'] as AuthMode[]).map((m) => (
              <Pressable
                key={m}
                onPress={() => { setMode(m); setError(''); }}
                style={{
                  flex: 1,
                  paddingVertical: 10,
                  alignItems: 'center',
                  borderRadius: 12,
                  backgroundColor: mode === m ? '#dde1e7' : 'transparent',
                  boxShadow: mode === m ? NEU_SHADOW.raisedSm : 'none',
                }}
              >
                <Text
                  style={{
                    fontFamily: 'Glow Sans SC',
                    fontSize: 15,
                    fontWeight: mode === m ? '700' : '400',
                    color: mode === m ? '#4a5580' : '#8a9ab5',
                  }}
                >
                  {m === 'login' ? '登录' : '注册'}
                </Text>
              </Pressable>
            ))}
          </View>

          {/* 输入区域 */}
          <View style={{ gap: 16, marginBottom: 8 }}>
            {/* 用户名 */}
            <View>
              <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 13, color: '#8a9ab5', marginBottom: 8, marginLeft: 4 }}>
                用户名
              </Text>
              <TextInput
                style={{
                  backgroundColor: '#dde1e7',
                  borderRadius: 14,
                  paddingHorizontal: 18,
                  paddingVertical: 14,
                  fontSize: 15,
                  color: '#3a3f5c',
                  fontFamily: 'Glow Sans SC',
                  boxShadow: NEU_SHADOW.inset,
                }}
                placeholder="字母/数字/下划线"
                placeholderTextColor="#a0aec0"
                value={username}
                onChangeText={setUsername}
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>

            {/* 密码 */}
            <View>
              <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 13, color: '#8a9ab5', marginBottom: 8, marginLeft: 4 }}>
                密码
              </Text>
              <View style={{ position: 'relative' }}>
                <TextInput
                  style={{
                    backgroundColor: '#dde1e7',
                    borderRadius: 14,
                    paddingHorizontal: 18,
                    paddingVertical: 14,
                    paddingRight: 54,
                    fontSize: 15,
                    color: '#3a3f5c',
                    fontFamily: 'Glow Sans SC',
                    boxShadow: NEU_SHADOW.inset,
                  }}
                  placeholder="至少6位"
                  placeholderTextColor="#a0aec0"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                />
                <Pressable
                  onPress={() => setShowPassword(!showPassword)}
                  style={{ position: 'absolute', right: 16, top: 14 }}
                >
                  <Text style={{ fontSize: 18 }}>{showPassword ? '🙈' : '👁'}</Text>
                </Pressable>
              </View>
            </View>

            {/* 确认密码（注册时显示） */}
            {mode === 'register' && (
              <View>
                <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 13, color: '#8a9ab5', marginBottom: 8, marginLeft: 4 }}>
                  确认密码
                </Text>
                <TextInput
                  style={{
                    backgroundColor: '#dde1e7',
                    borderRadius: 14,
                    paddingHorizontal: 18,
                    paddingVertical: 14,
                    fontSize: 15,
                    color: '#3a3f5c',
                    fontFamily: 'Glow Sans SC',
                    boxShadow: NEU_SHADOW.inset,
                  }}
                  placeholder="再次输入密码"
                  placeholderTextColor="#a0aec0"
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  secureTextEntry={!showPassword}
                />
              </View>
            )}
          </View>

          {/* 错误信息 */}
          {error ? (
            <Text style={{ color: '#e05555', fontSize: 13, marginTop: 8, marginLeft: 4, fontFamily: 'Glow Sans SC' }}>
              {error}
            </Text>
          ) : null}

          {/* 用户协议（注册时显示） */}
          {mode === 'register' && (
            <Pressable
              onPress={() => setAgreed(!agreed)}
              style={{ flexDirection: 'row', alignItems: 'center', marginTop: 16, gap: 10 }}
            >
              <View
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 6,
                  backgroundColor: '#dde1e7',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: agreed ? NEU_SHADOW.pressed : NEU_SHADOW.raisedSm,
                }}
              >
                {agreed && <Text style={{ fontSize: 13, color: '#4a5580' }}>✓</Text>}
              </View>
              <Text style={{ fontSize: 12, color: '#8a9ab5', fontFamily: 'Glow Sans SC', flex: 1 }}>
                我已阅读并同意{' '}
                <Text style={{ color: '#6376c8' }}>《用户协议》</Text>
                {' '}和{' '}
                <Text style={{ color: '#6376c8' }}>《隐私政策》</Text>
              </Text>
            </Pressable>
          )}

          {/* 提交按钮 */}
          <Pressable
            onPress={handleSubmit}
            disabled={loading}
            style={({ pressed }) => ({
              marginTop: 28,
              borderRadius: 16,
              paddingVertical: 16,
              alignItems: 'center',
              backgroundColor: '#6376c8',
              boxShadow: pressed ? NEU_SHADOW.pressed : NEU_SHADOW.primary,
              transform: [{ scale: pressed ? 0.97 : 1 }],
            })}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={{ fontFamily: 'Glow Sans SC', fontSize: 16, fontWeight: '700', color: '#fff' }}>
                {mode === 'login' ? '登录' : '创建账号'}
              </Text>
            )}
          </Pressable>

          {/* 底部切换提示 */}
          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 20, gap: 4 }}>
            <Text style={{ fontSize: 13, color: '#8a9ab5', fontFamily: 'Glow Sans SC' }}>
              {mode === 'login' ? '还没有账号？' : '已有账号？'}
            </Text>
            <Pressable onPress={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}>
              <Text style={{ fontSize: 13, color: '#6376c8', fontFamily: 'Glow Sans SC', fontWeight: '600' }}>
                {mode === 'login' ? '立即注册' : '去登录'}
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}
