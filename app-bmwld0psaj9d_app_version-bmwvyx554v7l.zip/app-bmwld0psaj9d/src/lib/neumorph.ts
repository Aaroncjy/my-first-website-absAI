// 软立体风格设计系统 - 统一光影常量
// 软立体阴影：左上高光 + 右下暗影
export const NEU_SHADOW = {
  // 浮起态（默认卡片、按钮）
  raised: '6px 6px 14px rgba(163,177,198,0.65), -6px -6px 14px rgba(255,255,255,0.88)',
  // 轻微浮起
  raisedSm: '4px 4px 8px rgba(163,177,198,0.55), -4px -4px 8px rgba(255,255,255,0.80)',
  // 按下态（active状态）
  pressed: '2px 2px 5px rgba(163,177,198,0.55), -1px -1px 3px rgba(255,255,255,0.75)',
  // 凹陷（input框）
  inset: 'inset 4px 4px 8px rgba(163,177,198,0.55), inset -4px -4px 8px rgba(255,255,255,0.80)',
  // 主色按钮阴影
  primary: '4px 4px 10px rgba(99,118,200,0.45), -3px -3px 8px rgba(255,255,255,0.55)',
} as const;

// 软立体基础背景色
export const NEU_BG = '#dde1e7';
export const NEU_BG_DARK = '#2a2e35';

// 动画时长
export const NEU_DURATION = 150;
