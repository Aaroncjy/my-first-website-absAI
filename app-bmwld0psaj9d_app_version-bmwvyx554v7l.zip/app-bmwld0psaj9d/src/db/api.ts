// 数据库API封装
import { supabase } from '@/client/supabase';
import type { Conversation, Message, Profile } from '@/types/types';

// ===== 用户资料 =====

export async function getProfile(userId: string): Promise<Profile | null> {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  return data;
}

export async function updateProfile(
  userId: string,
  updates: Partial<Pick<Profile, 'username' | 'avatar_url'>>
): Promise<void> {
  await supabase.from('profiles').update(updates).eq('id', userId);
}

// ===== 对话管理 =====

export async function getConversations(userId: string): Promise<Conversation[]> {
  const { data } = await supabase
    .from('conversations')
    .select('*')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false })
    .limit(100);
  return Array.isArray(data) ? data : [];
}

export async function createConversation(userId: string, title = '新对话'): Promise<Conversation | null> {
  const { data } = await supabase
    .from('conversations')
    .insert({ user_id: userId, title })
    .select()
    .maybeSingle();
  return data;
}

export async function deleteConversation(id: string): Promise<void> {
  await supabase.from('conversations').delete().eq('id', id);
}

export async function updateConversationTitle(id: string, title: string): Promise<void> {
  await supabase.from('conversations').update({ title }).eq('id', id);
}

// ===== 消息管理 =====

export async function getMessages(conversationId: string): Promise<Message[]> {
  const { data } = await supabase
    .from('messages')
    .select('*')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true })
    .limit(200);
  return Array.isArray(data) ? data : [];
}

export async function insertMessage(
  conversationId: string,
  role: 'user' | 'assistant',
  content: string
): Promise<Message | null> {
  const { data } = await supabase
    .from('messages')
    .insert({ conversation_id: conversationId, role, content })
    .select()
    .maybeSingle();
  return data;
}
